<?php
/*
Plugin Name: Whatsapp Chat
Plugin URI: http://sitesteroid.com/whatsapp-chat-plugin-for-osclass/
Description: Whatsapp Chat plugin helps visitors or Buyers to easily Chat with the seller who listed the particular item. It can be used to show WhatsApp Chat button in different shapes and styles on listing details pages.
Version: 1.2.0
Author: SiteSteroid
Author URI: http://www.sitesteroid.com/
Short Name: whatsappchat
Plugin update URI: whatsapp-chat
*/
	$GLOBALS['whatsapp_chat_ver']='1.2.0';
	require_once 'functions.php';
	require_once 'whatsapp_chat.php';
	
    function whatsapp_chat_install() {
		WhatsappChat::newInstance()->import('whatsapp_chat/struct.sql') ;
		whatsapp_chat_data_default();
    }

    function whatsapp_chat_uninstall() {
		whatsapp_chat_data_delete();
    }
	
	
	function whatsapp_chat_config_link() {
        osc_redirect_to(osc_route_admin_url('whatsapp_chat_conf'));
    }
	
	
	/**
    * Create a menu on the admin panel
    */
    function whatsapp_chat_admin_menu() {
		osc_add_admin_submenu_page('plugins', 'Whatsapp Chat', osc_route_admin_url('whatsapp_chat_conf'), 'whatsapp_chat_settings', 'administrator');
    }
	/**
     * ADD ROUTES (VERSION 3.2+)
     */
    osc_add_route('whatsapp_chat_conf', 'whatsapp_chat/admin/conf', 'whatsapp_chat/admin/conf', osc_plugin_folder(__FILE__).'admin/conf.php');
	

    /**
     * ADD HOOKS
     */
    osc_register_plugin(osc_plugin_path(__FILE__), 'whatsapp_chat_install');
    osc_add_hook(osc_plugin_path(__FILE__)."_uninstall", 'whatsapp_chat_uninstall');
	osc_add_hook(osc_plugin_path(__FILE__). "_configure", 'whatsapp_chat_config_link');	
	osc_add_hook('admin_menu_init', 'whatsapp_chat_admin_menu'); 
	
	$ask_seller_permission = osc_get_preference('ask_seller_permission', 'whatsapp_chat');
	if($ask_seller_permission=='enable')
	{
		osc_add_hook('item_form', 'seller_permission_selector');
		osc_add_hook('item_edit', 'seller_permission_selector');
		osc_add_hook('edited_item', 'seller_permission_save_values');
	}
	
	//display whatsapp chat button at selected positions
	$btn_disp_pos=explode(",", osc_get_preference('btn_disp_pos', 'whatsapp_chat'));
	foreach($btn_disp_pos as $btn_disp_pos_value) {
		osc_add_hook($btn_disp_pos_value, 'whatsapp_chat_content');
	}
	
		
	//For osclass less than v3.1.1
	function whatsapp_chat_scripts_ltOsc311() {	
		echo '<link rel="stylesheet" href="'. osc_plugin_url('whatsapp_chat/css/whatsapp_chat.css') . 'whatsapp_chat.css'.'">';
    }
	
	// add javascript
    if(osc_version()<311) {
        osc_add_hook('footer', 'whatsapp_chat_scripts_ltOsc311');
    } else {
		osc_register_script('jquery', osc_assets_url('js/jquery.min.js'));         
		osc_enqueue_script('jquery');
		osc_enqueue_style('whatsapp_chat_css', osc_plugin_url('whatsapp_chat/css/whatsapp_chat.css') . 'whatsapp_chat.css');
    }
	osc_add_hook('footer', 'whatsapp_chat_overlay_content');
	osc_add_hook('footer', 'whatsapp_chat_hide_from_large_css');
?>