<?php
if ( !defined('ABS_PATH') ) { 
	exit('ABS_PATH is not loaded. Direct access is not allowed.');
}

/**
* Database functions for Share Tracking plugin
* 
*/

class WhatsappChat extends DAO {
	/**
	 * It references to self object: WhatsappChat.
	 * It is used as a singleton
	 */
	private static $instance;
	private $folder;
	const DATABASE_VERSION = '1';

	/**
	 * It creates a new WhatsappChat object class ir if it has been created
	 * before, it return the previous object
	 */
	public static function newInstance() {
		if (!self::$instance instanceof self) {
			self::$instance = new self;
		}
		return self::$instance;
	}

	/**
	 * Construct
	 */
	function __construct() {
		parent::__construct();
		$this->folder = basename(dirname(__FILE__));		
	}
	
	
	/**
	 * Get name of table storing share tracking
	 * @return string
	 */
	public function getTable_WhatsappChat() {
		return DB_TABLE_PREFIX . 't_whatsapp_chat';
	}		

	
	/**
	 * Check fields table exists
	 */
	public function tableExists_WhatsappChat() {
		$sql = "SHOW TABLES LIKE '" . $this->getTable_WhatsappChat() . "'";
		$result = $this->dao->query($sql);
		$result = $result->result();
		if (empty($result)) {
			return false;
		} else {
			return true; 
		}
	}
	
	/**
	 * Check fields column exists
	 */
	public function columnExists_Fields($column) {
		$sql = "
			SELECT * FROM information_schema.COLUMNS 
			WHERE TABLE_SCHEMA = DATABASE()
			AND TABLE_NAME = '" . $this->getTable_WhatsappChat() . "'
			AND COLUMN_NAME = '" . $column . "'
		";
		$result = $this->dao->query($sql);
		$result = $result->result();
		if (empty($result)) {
			return false;
		} else {
			return true; 
		}
	}	
	
	/**
	 * Get allow chat
	 * @param string $item_id	 	 
	 * @return array
	 */
	public function getValues($item_id) {
		$this->dao->select();
		$this->dao->from($this->getTable_WhatsappChat());
		$this->dao->where('fk_i_item_id', $item_id);
		$results = $this->dao->get();
		if (!$results) {
			return array();
		}
		return $results->result();
	}	
	
	/**
	 * Get attribute value
	 * @param string $item_id	 
	 * @return string
	 */
	public function getAllowChatValue($item_id) {
		$this->dao->select('allow_chat');
		$this->dao->from($this->getTable_WhatsappChat());
		$this->dao->where('fk_i_item_id', $item_id);
		$this->dao->limit(1);
		$results = $this->dao->get();
		if (!$results) {
			return '';
		}		
		$row = $results->row();
		$value = isset($row['allow_chat']) ? $row['allow_chat'] : '';
		return $value;
	}
	
	
	
	
	
	
	 
	
	/**
	 * Insert attribute value
	 * @param int $item_id
	 * @param string $allow_chat
	 * @return mixed	 
	 */
	public function insertValue($item_id,$allow_chat)	{
		$args = array(
			'fk_i_item_id' => $item_id,  
			'allow_chat' => $allow_chat
		);
		return $this->dao->insert($this->getTable_WhatsappChat(), $args);
	}	
		
	
	/**
	 * Set attribute value
	 * @param int $item_id
	 * @param string $allow_chat
	 * @return boolean	
	 */
	public function setValue($item_id,$allow_chat) {	
		$exists = $this->valueExists($item_id);
		if (!$exists) {
			return $this->insertValue($item_id, $allow_chat);
		}
		$cur_allow_chat = $this->getAllowChatValue($item_id);
		if ($allow_chat != $cur_allow_chat ) {
			$where = array('fk_i_item_id' => $item_id);
			$set = array('allow_chat' => $allow_chat);
			return $this->_update($this->getTable_WhatsappChat(), $set, $where);
		}
	}	
	
	
	
	/**
	 * Delete attribute value
	 * @param int $item_id
	 * @return boolean	 
	 */
	public function deleteValue($item_id) {
		return $this->dao->delete($this->getTable_WhatsappChat(), array('fk_i_item_id' => $item_id));
	}	
	
	
	/**
	 * Import sql file
	 * @param type $file 
	 */
	public function import($file) {
		$path = osc_plugin_resource($file) ;
		$sql = file_get_contents($path);
		if(!$this->dao->importSQL($sql)) {
			throw new Exception($this->dao->getErrorLevel().' - '.$this->dao->getErrorDesc());
		}
	}
					
	/**
	 * Remove tables
	 */
	public function uninstall()	{
		$this->dao->query(sprintf('DROP TABLE %s', $this->getTable_WhatsappChat()));
	}
	
	/**
	 * Update values
	 * @param int $table
	 * @param int $values 
	 * @param int $where
	 * @return boolean
	 */
	function _update($table, $values, $where) {
		$this->dao->from($table);
		$this->dao->set($values);
		$this->dao->where($where);
		return $this->dao->update();
	}
	
	/**
	 * Check if value exists
	 * @param string $item_id
	 * @return boolean
	 */
	public function valueExists($item_id) {
		$this->dao->select('fk_i_item_id');
		$this->dao->from($this->getTable_WhatsappChat());
		$this->dao->where('fk_i_item_id', $item_id);
		$this->dao->limit(1);
		$results = $this->dao->get();
		if (!$results) {
			return false;
		}		
		$row = $results->row();
		if (isset($row['fk_i_item_id'])) {
			return true;
		} else {
			return false;
		}
	}	
}



// END