<?php
function whatsapp_chat_data_default()
{
	osc_set_preference('chat_pre_text', 'I would like to know more details about your listing - ', 'whatsapp_chat', 'STRING');
	osc_set_preference('permission_ask_text', 'Allow buyers to chat with me via WhatsApp', 'whatsapp_chat', 'STRING');
	osc_set_preference('chat_desc_char_limit', '0', 'whatsapp_chat', 'STRING');
	osc_set_preference('chat_title_char_limit', '0', 'whatsapp_chat', 'STRING');
	osc_set_preference('min_digits', '10', 'whatsapp_chat', 'STRING');
	osc_set_preference('country_code', '+91', 'whatsapp_chat', 'STRING');
	osc_set_preference('btn_disp_screen', '', 'whatsapp_chat', 'STRING');
	osc_set_preference('with_country', 'enable', 'whatsapp_chat', 'STRING');
	osc_set_preference('ask_seller_permission', 'disable', 'whatsapp_chat', 'STRING');
	osc_set_preference('enable_existing', 'enable', 'whatsapp_chat', 'STRING');
	osc_set_preference('btn_disp_pos', 'item_detail', 'whatsapp_chat', 'STRING');
	osc_set_preference('chat_btn_size', 'small', 'whatsapp_chat', 'STRING');
	osc_set_preference('chat_btn_style', 'b3', 'whatsapp_chat', 'STRING');
	osc_set_preference('simple_social_comp', '', 'whatsapp_chat', 'STRING');
	osc_set_preference('mobile_custom_field', '', 'whatsapp_chat', 'STRING');
	osc_set_preference('chat_overlay_btn_enable','Enable', 'whatsapp_chat', 'STRING');
	osc_set_preference('chat_overlay_btn_size','small', 'whatsapp_chat', 'STRING');
	osc_set_preference('chat_overlay_btn_style','b4', 'whatsapp_chat', 'STRING');
	osc_set_preference('bitly_login', '', 'whatsapp_chat', 'STRING');
	osc_set_preference('bitly_api_key', '', 'whatsapp_chat', 'STRING');
	osc_set_preference('registered_only', '', 'whatsapp_chat', 'STRING');
	osc_set_preference('user_profile_number', '', 'whatsapp_chat', 'STRING');
}
function whatsapp_chat_data_delete()
{
	osc_delete_preference('chat_pre_text', 'whatsapp_chat');
	osc_delete_preference('permission_ask_text', 'whatsapp_chat');
	osc_delete_preference('chat_title_char_limit', 'whatsapp_chat');
	osc_delete_preference('min_digits', 'whatsapp_chat');
	osc_delete_preference('country_code', 'whatsapp_chat');
	osc_delete_preference('chat_desc_char_limit', 'whatsapp_chat');
	osc_delete_preference('btn_disp_screen', 'whatsapp_chat');
	osc_delete_preference('with_country', 'whatsapp_chat');
	osc_delete_preference('ask_seller_permission', 'whatsapp_chat');
	osc_delete_preference('enable_existing', 'whatsapp_chat');
	osc_delete_preference('btn_disp_pos', 'whatsapp_chat');
	osc_delete_preference('chat_btn_size', 'whatsapp_chat');
	osc_delete_preference('chat_btn_style', 'whatsapp_chat');
	osc_delete_preference('simple_social_comp', 'whatsapp_chat');
	osc_delete_preference('mobile_custom_field', 'whatsapp_chat');
	osc_delete_preference('chat_overlay_btn_enable', 'whatsapp_chat');
	osc_delete_preference('chat_overlay_btn_size', 'whatsapp_chat');
	osc_delete_preference('chat_overlay_btn_style', 'whatsapp_chat');
	osc_delete_preference('bitly_login', 'whatsapp_chat');
	osc_delete_preference('bitly_api_key', 'whatsapp_chat');
	osc_delete_preference('whatsapp_chat_categories', 'whatsapp_chat');

	osc_delete_preference('registered_only', 'whatsapp_chat');
	osc_delete_preference('user_profile_number', 'whatsapp_chat');
}



function whatsapp_chat_get_short_link($longUrl)
{
	$bitly_login = osc_get_preference('bitly_login', 'whatsapp_chat');
	$bitly_api_key = osc_get_preference('bitly_api_key', 'whatsapp_chat');
	if(trim($bitly_login)=="" || trim($bitly_api_key)=="")
	{
		return(rawurlencode($longUrl));
	}
	$api = 'http://api.adf.ly/api.php?';
$query = array(
'key' => $bitly_api_key,
'uid' => $bitly_login,
'advert_type' => 'int',
'domain' => 'adf.ly',
'url' => $longUrl
);
$api = $api . http_build_query($query);
$data = file_get_contents($api);
return $data;





}
function get_whatsapp_chat_link($listing_url,$btn_pos)
{
	$chat_tracking_enable = osc_get_preference('chat_tracking_enable', 'whatsapp_chat');
	if($chat_tracking_enable=='Enable')
	{
		if (strpos($chat_tracking_enable,'?') !== false) {
			return $listing_url.'&utm_source=WhatsApp&utm_medium=IM&utm_campaign=whatsapp-chat-button-'.$btn_pos;
		}
		else
		{
			return $listing_url.'?utm_source=WhatsApp&utm_medium=IM&utm_campaign=whatsapp-chat-button-'.$btn_pos;
		}
	}
	else
		return $listing_url;
}

function get_whatsapp_chat_get_phone_num()
{
	$mobile_custom_field = osc_get_preference('mobile_custom_field', 'whatsapp_chat');
	if($mobile_custom_field<>"")
	{
		/* for theme zara start */
		if($mobile_custom_field=="themeZara"){
			$mobile_zara = '';
			if($mobile_zara == '') { $mobile_zara = osc_item_city_area(); }
			if($mobile_zara == '' && osc_item_user_id() <> 0) { $mobile_zara = $item_user['s_phone_mobile']; }
			if($mobile_zara == '' && osc_item_user_id() <> 0) { $mobile_zara = $item_user['s_phone_land']; }
			return $mobile_zara;
		}
		/* for theme zara end*/
		/* for theme veronica start */
		if($mobile_custom_field=="themeVeronica"){
			$veronika_item_extra = veronika_item_extra( osc_item_id() );
			$mobile_veronica = $veronika_item_extra['s_phone'];
			return $mobile_veronica;
		}
		/* for theme veronica end*/

		$meta_fields=Item::newInstance()->metaFields(osc_item_id());
		foreach ($meta_fields as $meta_field)
		{
			if($meta_field['s_slug']==$mobile_custom_field)
			{
				return($meta_field['s_value']);
				break;
			}
		}
	}elseif(function_exists('osc_telephone_number')){
		if (osc_item_id()) {
			$detail = Modelphone::newInstance()->t_check_value(osc_item_id());
			if (isset($detail['s_telephone'])) {
				return $detail['s_telephone'];
			}else{
				return "";
			}
		}else{
			return "";
		}
	}else{
		return "";
	}
}
function get_whatsapp_chat_profile_phone_num()
{
	$user_profile_number = osc_get_preference('user_profile_number', 'whatsapp_chat');
	$item_user_id="";
	if($user_profile_number=='enable')
	{
		$item_user_id=osc_item_user_id();
		if($item_user_id)
			return(osc_user_phone_mobile($item_user_id));
	}
	return "";
}
function get_whatsapp_chat_phone_num()
{
	$phone_num=get_whatsapp_chat_get_phone_num();
	$digit_count=preg_match_all( "/[0-9]/", $phone_num );
	if($digit_count<=0)
	{
		$phone_num=get_whatsapp_chat_profile_phone_num();
	}
	$digit_count=preg_match_all( "/[0-9]/", $phone_num );
	if($digit_count<=0)
		return "";
	else
	{
		$with_country = osc_get_preference('with_country', 'whatsapp_chat');
		if($with_country=='enable')
		{
			$min_digits = osc_get_preference('min_digits', 'whatsapp_chat');
			if($min_digits)
			{
				if($digit_count<=$min_digits)
				{
					$country_code = osc_get_preference('country_code', 'whatsapp_chat');
					$phone_num=''.$country_code.''.$phone_num;
				}
			}
		}
		else
		{
			$country_code = osc_get_preference('country_code', 'whatsapp_chat');
			$phone_num=''.$country_code.''.$phone_num;
		}
		$phone_num= preg_replace('/\D+/', '', $phone_num);
		return $phone_num;
	}
	return "";
}
function get_whatsapp_api_chat_link($btn_pos,$pre_text,$desc)
{
	$chat_title_char_limit = osc_get_preference('chat_title_char_limit', 'whatsapp_chat');
	$title="";
	if($chat_title_char_limit)
		$title=osc_highlight( osc_item_title() ,$chat_title_char_limit);
	$phone_num=get_whatsapp_chat_phone_num();
	$api_link='https://api.whatsapp.com/send?phone='.$phone_num.'&text='.rawurlencode($pre_text).' '.rawurlencode($title).' '.whatsapp_chat_get_short_link(get_whatsapp_chat_link(osc_item_url(),$btn_pos)).' '.$desc.'';
	return $api_link;
}
function show_whatsapp_chat_btn($item)
{
	if($item!=null)
	{
		$item_id = $item['fk_i_item_id'];
		$allow_chat_arr= WhatsappChat::newInstance()->getValues($item_id);
		if(empty($allow_chat_arr))
		{//check if Enable for existing is true
			$enable_existing = osc_get_preference('enable_existing', 'whatsapp_chat');
			if($enable_existing=='enable')
				return true;
			else
				return false;
		}else{
			return $allow_chat_arr[0]['allow_chat'];
		}
	}
	return false;
}
function allow_showing_button()
{
	$registered_only = osc_get_preference('registered_only', 'whatsapp_chat');
	if($registered_only=='enable')
	{
		if (osc_is_web_user_logged_in())
			return true;
		else
			return false;
	}else
	{
		return true;
	}
}
function whatsapp_chat_content()
{

	$item=osc_item();
	if($item!=null && show_whatsapp_chat_btn($item) && osc_is_ad_page() && allow_showing_button())
	{
		$cat_id = $item['fk_i_category_id'];
		$chat_cats = explode(",",osc_get_preference('whatsapp_chat_categories', 'whatsapp_chat'));
		if(osc_item_title() && in_array($cat_id,$chat_cats))
		{
			$chat_btn_size = osc_get_preference('chat_btn_size', 'whatsapp_chat');
			$chat_btn_style = osc_get_preference('chat_btn_style', 'whatsapp_chat');
			$pre_text = osc_get_preference('chat_pre_text', 'whatsapp_chat');
			$chat_desc_char_limit = osc_get_preference('chat_desc_char_limit', 'whatsapp_chat');
			$desc="";
			if($chat_desc_char_limit)
				$desc=osc_highlight( osc_item_description() ,$chat_desc_char_limit);
			$btn = '<div class="whatsapp-chat-btn"><a href="'.get_whatsapp_api_chat_link('normal',$pre_text,$desc).'" class="wabtn" target="_blank"><img src="'.osc_plugin_url('whatsapp_chat/images/whatsapp-chat-'.$chat_btn_style.'-'.$chat_btn_size.'.png').'whatsapp-chat-'.$chat_btn_style.'-'.$chat_btn_size.'.png"/> </a></div>';
			if(get_whatsapp_chat_phone_num()) //display btn only if there is valid phone number associated with the item
			{
				echo $btn;
			}
		}
	}
}
function whatsapp_chat_overlay_content()
{
	$item=osc_item();
	$desc="";
	if($item!=null && show_whatsapp_chat_btn($item) && osc_is_ad_page() && allow_showing_button())
	{
		$cat_id = $item['fk_i_category_id'];
		$chat_cats = explode(",",osc_get_preference('whatsapp_chat_categories', 'whatsapp_chat'));
		if(osc_item_title() && in_array($cat_id,$chat_cats))
		{
			$chat_overlay_btn_enable = osc_get_preference('chat_overlay_btn_enable', 'whatsapp_chat');
			if($chat_overlay_btn_enable=='Enable')
			{
				$chat_overlay_btn_size = osc_get_preference('chat_overlay_btn_size', 'whatsapp_chat');
				$chat_overlay_btn_style = osc_get_preference('chat_overlay_btn_style', 'whatsapp_chat');
				$pre_text = osc_get_preference('chat_pre_text', 'whatsapp_chat');
				$chat_desc_char_limit = osc_get_preference('chat_desc_char_limit', 'whatsapp_chat');
				if($chat_desc_char_limit)
					$desc=osc_highlight( osc_item_description() ,$chat_desc_char_limit);

				/* ---------- START whatsapp share overlay btn compatibility ---------------- */
				$share_btn = "";
				if(function_exists('whatsapp_share_overlay_content'))
				{
					$share_overlay_btn_enable = osc_get_preference('share_overlay_btn_enable', 'whatsapp_share');
					if($share_overlay_btn_enable=='Enable') // $show_share_overlay==1 check added for whatsapp chat plugin compatibility
					{
						$share_overlay_btn_size = osc_get_preference('share_overlay_btn_size', 'whatsapp_share');
						$share_overlay_btn_style = osc_get_preference('share_overlay_btn_style', 'whatsapp_share');
						$pre_text = osc_get_preference('share_pre_text', 'whatsapp_share');
						$share_desc_char_limit = osc_get_preference('share_desc_char_limit', 'whatsapp_share');
						if($share_desc_char_limit)
							$desc=osc_highlight( osc_item_description() ,$share_desc_char_limit);
						$share_btn = '<a href="'.get_whatsapp_api_share_link('overlay',$pre_text,$desc).'" "><img src="'.osc_plugin_url('whatsapp_share/images/whatsapp-share-'.$share_overlay_btn_style.'-'.$share_overlay_btn_size.'.png').'whatsapp-share-'.$share_overlay_btn_style.'-'.$share_overlay_btn_size.'.png"/> </a>';

					}
				}
				/* ---------- END whatsapp share overlay btn compatibility ---------------- */

				$btn = '<span class="whatsapp-chat-overlay-wrapper">
							<span class="whatsapp-chat-overlay-inner">
								<span class="whatsapp-chat-overlay-btn">
									<span class="whatsapp-chat-overlay-btn-holder">'
									.$share_btn.'
									<a href="'.get_whatsapp_api_chat_link('overlay',$pre_text,$desc).'"" class="whatsapp-chat-btn" target="_blank" >
										<img src="'.osc_plugin_url('whatsapp_chat/images/whatsapp-chat-'.$chat_overlay_btn_style.'-'.$chat_overlay_btn_size.'.png').'whatsapp-chat-'.$chat_overlay_btn_style.'-'.$chat_overlay_btn_size.'.png"/>
									</a>
									</span>
								</span>
							</span>
						</span>';
				if(get_whatsapp_chat_phone_num()) //display btn only if there is valid phone number associated with the item
				{
					echo $btn;
				}
			}
		}
	}
}


function whatsapp_chat_hide_from_large_css()
{
	$btn_disp_screen = osc_get_preference('btn_disp_screen', 'whatsapp_chat');
	if($btn_disp_screen=='small')
	{
		echo "<style>@media (min-width: 1024px) {.whatsapp-chat-btn{display:none!important;}}</style>";
	}
}

function seller_permission_selector ($cat_id = null, $item_id = null)
{
	$selected_cats=explode(",",osc_get_preference('whatsapp_chat_categories', 'whatsapp_chat'));
	$permission_ask_text = osc_get_preference('permission_ask_text', 'whatsapp_chat');
	if(in_array($cat_id , $selected_cats))
	{
		$permissionValue=WhatsappChat::newInstance()->getAllowChatValue($item_id);
		$checked = $permissionValue? 'checked="true"' : '';
		echo '<div class="controls checkbox">';
			echo '<input id="showWhatsappChat" type="checkbox" name="showWhatsappChat" '.$checked.' value="1"> ';
			echo '<label for="showWhatsappChat">'.$permission_ask_text.'</label>';
		echo '</div>';
	}
}

function seller_permission_save_values($item = null)
{
	$item_id = $item['pk_i_id'];
	$showWhatsappChat=Params::getParam('showWhatsappChat');
	WhatsappChat::newInstance()->setValue($item_id, htmlentities($showWhatsappChat));
}
?>
