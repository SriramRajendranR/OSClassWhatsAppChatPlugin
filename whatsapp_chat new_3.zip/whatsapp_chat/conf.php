<?php
	if(Params::getParam('plugin_action')=='save_categories') {
        osc_set_preference('whatsapp_chat_categories', Params::getParam("categories") ? implode(",",Params::getParam("categories"))  : '', 'whatsapp_chat', 'STRING');
		osc_set_preference('chat_pre_text', Params::getParam("pre_text"), 'whatsapp_chat', 'STRING');
		osc_set_preference('permission_ask_text', Params::getParam("permission_ask_text"), 'whatsapp_chat', 'STRING');
		osc_set_preference('chat_title_char_limit', Params::getParam("chat_title_char_limit"), 'whatsapp_chat', 'STRING');
		osc_set_preference('min_digits', Params::getParam("min_digits"), 'whatsapp_chat', 'STRING');
		osc_set_preference('country_code', Params::getParam("country_code"), 'whatsapp_chat', 'STRING');
		osc_set_preference('chat_desc_char_limit', Params::getParam("chat_desc_char_limit"), 'whatsapp_chat', 'STRING');
		osc_set_preference('btn_disp_screen', Params::getParam("btn_disp_screen"), 'whatsapp_chat', 'STRING');
		osc_set_preference('with_country', Params::getParam("with_country"), 'whatsapp_chat', 'STRING');
		osc_set_preference('ask_seller_permission', Params::getParam("ask_seller_permission"), 'whatsapp_chat', 'STRING');
		osc_set_preference('enable_existing', Params::getParam("enable_existing"), 'whatsapp_chat', 'STRING');
		osc_set_preference('btn_disp_pos', Params::getParam("btn_disp_pos") ? implode(",",Params::getParam("btn_disp_pos")) : '', 'whatsapp_chat', 'STRING');
		osc_set_preference('chat_btn_size', Params::getParam("chat_btn_size") ? Params::getParam("chat_btn_size")  : 'small', 'whatsapp_chat', 'STRING');
		osc_set_preference('chat_btn_style', Params::getParam("chat_btn_style") ? Params::getParam("chat_btn_style")  : 'b1', 'whatsapp_chat', 'STRING');
		osc_set_preference('simple_social_comp', Params::getParam("simple_social_comp"), 'whatsapp_chat', 'STRING');
		osc_set_preference('mobile_custom_field', Params::getParam("mobile_custom_field"), 'whatsapp_chat', 'STRING');

		osc_set_preference('chat_overlay_btn_enable', Params::getParam("chat_overlay_btn_enable") ? Params::getParam("chat_overlay_btn_enable")  : 'No', 'whatsapp_chat', 'STRING');
		osc_set_preference('chat_overlay_btn_size', Params::getParam("chat_overlay_btn_size") ? Params::getParam("chat_overlay_btn_size")  : 'small', 'whatsapp_chat', 'STRING');
		osc_set_preference('chat_overlay_btn_style', Params::getParam("chat_overlay_btn_style") ? Params::getParam("chat_overlay_btn_style")  : 'b1', 'whatsapp_chat', 'STRING');
		osc_set_preference('bitly_login', Params::getParam("bitly_login"), 'whatsapp_chat', 'STRING');
		osc_set_preference('bitly_api_key', Params::getParam("bitly_api_key"), 'whatsapp_chat', 'STRING');
		osc_set_preference('chat_tracking_enable',Params::getParam("chat_tracking_enable") ? Params::getParam("chat_tracking_enable")  : 'Enable', 'whatsapp_chat', 'STRING');
		osc_set_preference('tracking_show',Params::getParam("tracking_show") ? Params::getParam("tracking_show")  : 'Admin', 'whatsapp_chat', 'STRING');


		osc_set_preference('registered_only', Params::getParam("registered_only"), 'whatsapp_chat', 'STRING');
		osc_set_preference('user_profile_number', Params::getParam("user_profile_number"), 'whatsapp_chat', 'STRING');

		// HACK : This will make possible use of the flash messages ;)
        ob_get_clean();
		osc_add_flash_ok_message( __('Saved changes', 'whatsapp_chat') , 'admin');
        osc_redirect_to(osc_route_admin_url('whatsapp_chat_conf'));
    }

	osc_enqueue_script('jquery-treeview');
    $categories = Category::newInstance()->toTreeAll();
    $selected = explode(",",osc_get_preference('whatsapp_chat_categories', 'whatsapp_chat'));
	$pre_text = osc_get_preference('chat_pre_text', 'whatsapp_chat');
	$permission_ask_text = osc_get_preference('permission_ask_text', 'whatsapp_chat');
	$chat_title_char_limit = osc_get_preference('chat_title_char_limit', 'whatsapp_chat');
	$min_digits = osc_get_preference('min_digits', 'whatsapp_chat');
	$country_code = osc_get_preference('country_code', 'whatsapp_chat');
	$chat_desc_char_limit = osc_get_preference('chat_desc_char_limit', 'whatsapp_chat');
	$btn_disp_screen = osc_get_preference('btn_disp_screen', 'whatsapp_chat');
	$with_country = osc_get_preference('with_country', 'whatsapp_chat');
	$ask_seller_permission = osc_get_preference('ask_seller_permission', 'whatsapp_chat');
	$enable_existing = osc_get_preference('enable_existing', 'whatsapp_chat');
	$btn_disp_pos=explode(",", osc_get_preference('btn_disp_pos', 'whatsapp_chat'));
	$chat_btn_size = osc_get_preference('chat_btn_size', 'whatsapp_chat');
	$chat_btn_style = osc_get_preference('chat_btn_style', 'whatsapp_chat');
	$simple_social_comp = osc_get_preference('simple_social_comp', 'whatsapp_chat');
	$mobile_custom_field = osc_get_preference('mobile_custom_field', 'whatsapp_chat');
	$chat_overlay_btn_enable = osc_get_preference('chat_overlay_btn_enable', 'whatsapp_chat');
	$chat_overlay_btn_size = osc_get_preference('chat_overlay_btn_size', 'whatsapp_chat');
	$chat_overlay_btn_style = osc_get_preference('chat_overlay_btn_style', 'whatsapp_chat');
	$bitly_login = osc_get_preference('bitly_login', 'whatsapp_chat');
	$bitly_api_key = osc_get_preference('bitly_api_key', 'whatsapp_chat');
	$chat_tracking_enable = osc_get_preference('chat_tracking_enable', 'whatsapp_chat');
	$tracking_show = osc_get_preference('tracking_show', 'whatsapp_chat');
	$registered_only = osc_get_preference('registered_only', 'whatsapp_chat');
	$user_profile_number = osc_get_preference('user_profile_number', 'whatsapp_chat');
?>
<script type='text/javascript' src='<?php echo osc_assets_url('js/jquery.treeview.js'); ?>'></script>

<div id="edit-listing-visitor-count-config">
    <div class="form-horizontal">
        <form id="whatsapp_chat_config_form" action="<?php echo osc_admin_base_url(true); ?>" method="post">
		<input type="hidden" name="page" value="plugins" />
		<input type="hidden" name="action" value="renderplugin" />
		<input type="hidden" name="route" value="whatsapp_chat_conf" />
		<input type="hidden" name="plugin_action" value="save_categories" />
		<h2 class="render-title"><?php _e('Whatsapp Chat', 'whatsapp_chat');  echo ' v'.$GLOBALS['whatsapp_chat_ver'];?> </h2>
        <fieldset>
			<div class="form-row">
				<div class="form-label"><?php _e('Pre Text', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input id="pre_text" name="pre_text" type="text" value="<?php echo $pre_text; ?>"  />
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Title char limit', 'whatsapp_chat'); ?></div>
				<div class="form-controls"><input id="chat_title_char_limit" class="input-small" name="chat_title_char_limit" type="text" value="<?php echo $chat_title_char_limit; ?>"  />&nbsp;<i><?php _e('To avoid showing title give value as 0', 'whatsapp_chat'); ?></i></div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Description char limit', 'whatsapp_chat'); ?></div>
				<div class="form-controls"><input id="chat_desc_char_limit" class="input-small" name="chat_desc_char_limit" type="text" value="<?php echo $chat_desc_char_limit; ?>"  />&nbsp;<i><?php _e('To avoid showing description give value as 0', 'whatsapp_chat'); ?></i></div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Display device', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<div class="form-label-checkbox">
						<label>
							<input type="checkbox" id="btn_disp_screen" <?php echo ($btn_disp_screen=='small'? 'checked="true"' : ''); ?> name="btn_disp_screen" value="small" />
							<?php  _e('Display the button only on devices with small screen', 'whatsapp_chat'); ?>
						</label>
					</div>
				</div>
			</div>
			<h2 class="render-title separate-top"><?php _e('Whatsapp Chat Seller Mobile Number', 'whatsapp_chat'); ?></h2>
			<div class="form-row">
				<div class="form-label"><?php _e('Custom field slug for Seller\'s mobile number', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input id="mobile_custom_field" name="mobile_custom_field" type="text" value="<?php echo $mobile_custom_field; ?>"  />
					<p><i><?php _e('Note:Leave this blank for automatic configuration based on "TELEPHONE" plugin.', 'whatsapp_chat'); ?></i></p>
					<p><i><?php _e('Note:If you are using theme Zara then enter - themeZara, For theme Veronica then enter - themeVeronica.', 'whatsapp_chat'); ?></i></p>
					<p><i><?php _e('Make sure the custom field is of type TEXT', 'whatsapp_chat'); ?></i></p>
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Stored with country code?', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<div class="form-label-checkbox">
						<label>
							<input type="checkbox" id="with_country" <?php echo ($with_country=='enable'? 'checked="true"' : ''); ?> name="with_country" value="enable" />
							<?php  _e('Tick if the numbers are stored with country code pre fixed', 'whatsapp_chat'); ?>
						</label>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Minimum digits excluding country code', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input class="input-small error" id="min_digits" name="min_digits" type="text" value="<?php echo $min_digits; ?>"  />
					&nbsp;<i><?php _e('The phone number will be prefixed with default country code if the minimum number of digits is not found in the given phone number.', 'whatsapp_chat'); ?></i>
					<p><i><?php _e('Note:If you need to avoid this functionality give 0 or leave it blank.', 'whatsapp_chat'); ?></i></p>
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Default country code', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input class="input-small error" id="country_code" name="country_code" type="text" value="<?php echo $country_code; ?>"  />
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Ask seller permission', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<div class="form-label-checkbox">
						<label>
							<input type="checkbox" id="ask_seller_permission" <?php echo ($ask_seller_permission=='enable'? 'checked="true"' : ''); ?> name="ask_seller_permission" value="enable" />
							<?php  _e('If this is ticked, seller will be prompted with option to enable or disable whatsapp chat while publishing post.', 'whatsapp_chat'); ?>
						</label>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Permission text', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input id="permission_ask_text" name="permission_ask_text" type="text" value="<?php echo $permission_ask_text; ?>"  />
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Enable default for existing', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<div class="form-label-checkbox">
						<label>
							<input type="checkbox" id="enable_existing" <?php echo ($enable_existing=='enable'? 'checked="true"' : ''); ?> name="enable_existing" value="enable" />
							<?php  _e('If this is ticked, all existing listings with a valid seller\'s mobile number associated with will be enabled whatsapp chat option irrespective of above option - \'Ask seller permission
\'', 'whatsapp_chat'); ?>
						</label>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Show to registered only', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<div class="form-label-checkbox">
						<label>
							<input type="checkbox" id="registered_only" <?php echo ($registered_only=='enable'? 'checked="true"' : ''); ?> name="registered_only" value="enable" />
							<?php  _e('Show the WhatsApp chat button to registered users only. If not ticked button will be displayed to all users.', 'whatsapp_chat'); ?>
						</label>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Alternate Number', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<div class="form-label-checkbox">
						<label>
							<input type="checkbox" id="user_profile_number" <?php echo ($user_profile_number=='enable'? 'checked="true"' : ''); ?> name="user_profile_number" value="enable" />
							<?php  _e('Use the phone number saved in user profile if a number is not associated with the listing.', 'whatsapp_chat'); ?>
						</label>
					</div>
				</div>
			</div>
			<h2 class="render-title separate-top"><?php _e('Whatsapp Chat Button Display Locations', 'whatsapp_chat'); ?></h2>
			<div class="form-row">
				<div><?php _e('Select the positions in which the whatsapp chat button to be shown:', 'whatsapp_chat'); ?></div>
				<div><i><?php _e('Note: Some themes will not support all the below locations. Use trial and error method to find the best location.', 'whatsapp_chat'); ?></i></div>
				<div class="form-label"></div>
				<div class="form-controls">
					<?php
					$available_pos = array(
						"Header" => "header",
						"Before Main"=>"before-main",
						"After Main"=>"after-main",
						"Inside Main"=>"inside-main",
						"Before content"=>"before-content",
						"Item Detail"=>"item_detail",
						"Footer"=>"footer"
					);
					foreach($available_pos as $available_pos_name => $available_pos_value) { ?>
						<div class="form-label-checkbox">
							<label>
								<input type="checkbox" <?php echo (in_array($available_pos_value,$btn_disp_pos) ? 'checked="true"' : ''); ?> name="btn_disp_pos[]" value="<?php echo $available_pos_value; ?>" />
								<?php switch($available_pos_name){
									case "Header":
										 _e("Header", 'whatsapp_chat');
										break;
									case "Before Main":
										 _e("Before Main", 'whatsapp_chat');
										break;
									case "After Main":
										 _e("After Main", 'whatsapp_chat');
										break;
									case "Inside Main":
										 _e("Inside Main", 'whatsapp_chat');
										break;
									case "Before content":
										 _e("Before content", 'whatsapp_chat');
										break;
									case "Item Detail":
										 _e("Item Detail", 'whatsapp_chat');
										break;
									case "Footer":
										 _e("Footer", 'whatsapp_chat');
										break;
								}?>
							</label>
						</div>
					<?php }	?>

				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Button Size', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input type="radio" name="chat_btn_size" value="small" <?php if($chat_btn_size=='small') {echo 'checked';}?> ><?php _e('Small', 'whatsapp_chat'); ?>
					<input type="radio" name="chat_btn_size" value="medium" <?php if($chat_btn_size=='medium') {echo 'checked';}?> ><?php _e('Medium', 'whatsapp_chat'); ?>
					<input type="radio" name="chat_btn_size" value="large" <?php if($chat_btn_size=='large') {echo 'checked';}?> ><?php _e('Large', 'whatsapp_chat'); ?>
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Button Style', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input type="radio" name="chat_btn_style" value="b1" <?php if($chat_btn_style=='b1') {echo 'checked';}?> >
					<img src="<?php echo osc_plugin_url('whatsapp_chat/images/whatsapp-chat-b1-small.png'); ?>whatsapp-chat-b1-small.png"/>

					<input type="radio" name="chat_btn_style" value="b2" <?php if($chat_btn_style=='b2') {echo 'checked';}?> >
					<img src="<?php echo osc_plugin_url('whatsapp_chat/images/whatsapp-chat-b2-small.png'); ?>whatsapp-chat-b2-small.png"/>

					<input type="radio" name="chat_btn_style" value="b3" <?php if($chat_btn_style=='b3') {echo 'checked';}?> >
					<img src="<?php echo osc_plugin_url('whatsapp_chat/images/whatsapp-chat-b3-small.png'); ?>whatsapp-chat-b3-small.png"/>

					<input type="radio" name="chat_btn_style" value="b4" <?php if($chat_btn_style=='b4') {echo 'checked';}?> >
					<img src="<?php echo osc_plugin_url('whatsapp_chat/images/whatsapp-chat-b4-small.png'); ?>whatsapp-chat-b4-small.png"/>
				</div>
			</div>

			<h2 class="render-title"><?php _e('Overlay Chat Button Settings', 'whatsapp_chat'); ?></h2>
			<div class="form-row">
				<div class="form-label"><?php _e('Enable', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<div class="form-label-checkbox">
						<label>
							<input type="checkbox" id="chat_overlay_btn_enable" <?php echo ($chat_overlay_btn_enable=='Enable'? 'checked="true"' : ''); ?> name="chat_overlay_btn_enable" value="Enable" />
							<?php  _e('Show the page overlay chat button', 'whatsapp_chat'); ?>
						</label>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Button Size', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input type="radio" name="chat_overlay_btn_size" value="small" <?php if($chat_overlay_btn_size=='small') {echo 'checked';}?> ><?php _e('Small', 'whatsapp_chat'); ?>
					<input type="radio" name="chat_overlay_btn_size" value="medium" <?php if($chat_overlay_btn_size=='medium') {echo 'checked';}?> ><?php _e('Medium', 'whatsapp_chat'); ?>
					<input type="radio" name="chat_overlay_btn_size" value="large" <?php if($chat_overlay_btn_size=='large') {echo 'checked';}?> ><?php _e('Large', 'whatsapp_chat'); ?>
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('Button Style', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input type="radio" name="chat_overlay_btn_style" value="b1" <?php if($chat_overlay_btn_style=='b1') {echo 'checked';}?> >
					<img src="<?php echo osc_plugin_url('whatsapp_chat/images/whatsapp-chat-b1-small.png'); ?>whatsapp-chat-b1-small.png"/>

					<input type="radio" name="chat_overlay_btn_style" value="b2" <?php if($chat_overlay_btn_style=='b2') {echo 'checked';}?> >
					<img src="<?php echo osc_plugin_url('whatsapp_chat/images/whatsapp-chat-b2-small.png'); ?>whatsapp-chat-b2-small.png"/>

					<input type="radio" name="chat_overlay_btn_style" value="b3" <?php if($chat_overlay_btn_style=='b3') {echo 'checked';}?> >
					<img src="<?php echo osc_plugin_url('whatsapp_chat/images/whatsapp-chat-b3-small.png'); ?>whatsapp-chat-b3-small.png"/>

					<input type="radio" name="chat_overlay_btn_style" value="b4" <?php if($chat_overlay_btn_style=='b4') {echo 'checked';}?> >
					<img src="<?php echo osc_plugin_url('whatsapp_chat/images/whatsapp-chat-b4-small.png'); ?>whatsapp-chat-b4-small.png"/>
				</div>
			</div>
			<h2 class="render-title"><?php _e('Shorten URL', 'whatsapp_chat'); ?></h2>
			<div class="form-row">
				<div><?php _e('Fill the following details provided by adf.ly to enable url shortening service', 'whatsapp_chat'); ?></div>
				<div class="form-label"><?php _e('user id', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input id="bitly_login" name="bitly_login" type="text" value="<?php echo $bitly_login; ?>"  />
				</div>
			</div>
			<div class="form-row">
				<div class="form-label"><?php _e('API KEY', 'whatsapp_chat'); ?></div>
				<div class="form-controls">
					<input id="bitly_api_key" name="bitly_api_key" type="text" value="<?php echo $bitly_api_key; ?>"  />
				</div>
				<p><?php _e('Note:localhost urls will not be shortened by adf.ly', 'whatsapp_chat'); ?></p>
			</div>

			<div class="form-row">
				<h2 class="render-title"><?php _e('Category', 'whatsapp_chat'); ?></h2>
                <div><?php _e('Select the categories where you want to enable whatsapp chat:', 'whatsapp_chat'); ?></div>
                <div class="separate-top">
					<div class="form-label">
						<a href="javascript:void(0);" onclick="checkAll('cat_tree', true); return false;"><?php _e('Check all', 'whatsapp_chat'); ?></a> &middot;
						<a href="javascript:void(0);" onclick="checkAll('cat_tree', false); return false;"><?php _e('Uncheck all', 'whatsapp_chat'); ?></a>
					</div>
					<div class="form-controls">
						<ul id="cat_tree">
							<?php CategoryForm::categories_tree($categories, $selected); ?>
						</ul>
					</div>
                </div>
            </div>
            <div class="form-actions">
                <input type="submit" id="cfield_save" value="<?php echo osc_esc_html( __('Save changes', 'whatsapp_chat') ); ?>" class="btn btn-submit" />
            </div>
        </fieldset>
		</form>
    </div>
</div>

 <script type="text/javascript">
        // check all the categories
        function checkAll(id, check) {
            aa = $('#' + id + ' input[type=checkbox]').each(function() {
                $(this).prop('checked', check);
            });
        }

        function checkCat(id, check) {
            aa = $('#cat' + id + ' input[type=checkbox]').each(function() {
                $(this).prop('checked', check);
            });
        }

		 $(document).ready(function(){
        $("#cat_tree").treeview({
            animated: "fast",
            collapsed: true
        });


    });
    </script>
