CREATE TABLE IF NOT EXISTS `/*TABLE_PREFIX*/t_whatsapp_chat` (
  `fk_i_item_id` int(10) NOT NULL,
  `allow_chat` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fk_i_item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
